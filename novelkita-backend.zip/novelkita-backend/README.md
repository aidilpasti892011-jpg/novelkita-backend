# NovelKita Backend

Backend API untuk platform NovelKita — Express.js + PostgreSQL + Prisma ORM + JWT Authentication.
Ini kode sungguhan yang siap dijalankan di komputer/server (bukan berjalan otomatis di dalam chat ini).

## Tech Stack
- Node.js + Express.js
- PostgreSQL + Prisma ORM
- JWT (access token pendek + refresh token di cookie httpOnly)
- bcryptjs untuk hashing password
- Zod untuk validasi input
- express-rate-limit untuk rate limiting

> Catatan soal Next.js: stack asli menyebut Next.js untuk sisi frontend. Backend ini murni REST API (Express) yang **independen dari framework frontend** — bisa dikonsumsi oleh Next.js, atau oleh tiga prototipe frontend (app pembaca, dashboard author, admin panel) yang sudah dibuat sebelumnya, cukup dengan mengganti pemanggilan `localStorage` menjadi `fetch()` ke endpoint di bawah.

## Menjalankan di Lokal

```bash
# 1. Install dependency
npm install

# 2. Siapkan PostgreSQL (lokal atau lewat Docker), lalu salin env
cp .env.example .env
# edit .env — isi DATABASE_URL dan dua JWT secret dengan nilai asli

# 3. Buat tabel di database dari schema Prisma
npm run prisma:migrate

# 4. (opsional) isi data contoh
npm run seed

# 5. Jalankan server dengan auto-reload
npm run dev
```

Server akan jalan di `http://localhost:4000` (atau sesuai `PORT` di `.env`). Cek `GET /api/health` untuk memastikan server hidup.

## Struktur Folder

```
prisma/
  schema.prisma     — skema database (8 model: User, Novel, Chapter, Comment,
                       Bookmark, ReadingHistory, Notification, Report, + AuditLog & RefreshToken)
  seed.js            — data contoh (novel, author, admin, reader demo)
src/
  app.js             — perakitan Express app (middleware + routes)
  server.js           — entry point, menjalankan app.listen()
  lib/prisma.js       — instance PrismaClient tunggal
  utils/jwt.js        — sign/verify access & refresh token
  utils/audit.js      — helper menulis ke tabel audit_logs
  middleware/auth.js  — authenticate, requireRole, requireOwnerOrRole
  middleware/rateLimit.js
  middleware/validate.js
  controllers/        — logika tiap fitur (auth, novel, chapter, bookmark, comment, history, admin)
  routes/              — pemetaan endpoint → controller + middleware
```

## Ringkasan Endpoint

| Area | Endpoint |
|---|---|
| Auth | `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/logout`, `POST /api/auth/refresh`, `GET /api/auth/me` |
| Novel | `GET /api/novels`, `GET /api/novels/:id`, `POST /api/novels`, `PUT /api/novels/:id`, `DELETE /api/novels/:id` |
| Chapter | `GET /api/chapters?novelId=`, `GET /api/chapters/:id`, `POST /api/chapters`, `PUT /api/chapters/:id`, `DELETE /api/chapters/:id` |
| Bookmark | `POST /api/bookmarks`, `DELETE /api/bookmarks/:novelId`, `GET /api/bookmarks/user` |
| Comment | `POST /api/comments`, `PUT /api/comments/:id`, `POST /api/comments/:id/like`, `DELETE /api/comments/:id`, `GET /api/comments/novel/:id` |
| Reading History | `POST /api/history`, `GET /api/history` |
| Reports (user) | `POST /api/reports` |
| Admin | `GET/PUT/DELETE /api/admin/users`, `GET /api/admin/novels`, `PUT /api/admin/novels/:id/status`, `PUT /api/admin/comments/:id/hide|unhide`, `GET/PUT /api/admin/reports`, `GET /api/admin/audit-logs` (khusus Super Admin) |

Detail lengkap tiap endpoint (field request/response) ada di dokumen **"NovelKita — Spesifikasi Database & API"** yang sudah dibuat sebelumnya — kode ini adalah implementasi nyata dari spesifikasi tersebut.

## Cara Kerja Autentikasi

1. `POST /api/auth/login` mengembalikan `accessToken` (JSON, umur 15 menit) dan menaruh `refreshToken` di cookie httpOnly (umur 7 hari).
2. Frontend menyimpan `accessToken` di memori (bukan localStorage — lebih aman dari XSS) dan mengirimkannya lewat header `Authorization: Bearer <token>` di setiap request yang butuh login.
3. Saat `accessToken` kedaluwarsa, panggil `POST /api/auth/refresh` (cookie terkirim otomatis oleh browser) untuk mendapat `accessToken` baru tanpa perlu login ulang.
4. `POST /api/auth/logout` menghapus refresh token dari database + cookie, sehingga token lama tidak bisa dipakai lagi.

## Role & Permission

Implementasi middleware `requireRole()` dan `requireOwnerOrRole()` di `src/middleware/auth.js` mengikuti matriks permission di dokumen spesifikasi: Reader hanya baca/komentar/bookmark; Author bisa kelola novel & chapter **miliknya sendiri** (dicek lewat `getNovelOwnerId`/`getChapterOwnerId`, bukan cuma role); Admin bisa kelola semua novel/user/komentar/laporan; Super Admin punya semua akses termasuk audit log.

## Menghubungkan ke Frontend yang Sudah Ada

Tiga prototipe NovelKita sebelumnya (app pembaca, dashboard author, admin panel) memakai `localStorage`. Untuk menyambungkannya ke backend ini:
1. Ganti setiap `localStorage.getItem/setItem` dengan `fetch('http://localhost:4000/api/...')`.
2. Simpan `accessToken` di state React/JS biasa (bukan localStorage) setelah login berhasil.
3. Tambahkan header `Authorization: Bearer <token>` di setiap request yang butuh login.
4. Karena backend ini satu sumber data terpusat, ketiga bagian frontend otomatis "nyambung" satu sama lain — masalah "login tidak sinkron antar-artifact" di versi localStorage otomatis selesai di sini.

## Keamanan yang Sudah Diterapkan
- Password di-hash dengan **bcrypt** (cost 12), tidak pernah disimpan/dikirim plaintext.
- **JWT access + refresh token** dua lapis, refresh token disimpan ter-hash (SHA-256) di database supaya bisa dicabut saat logout.
- **Role validation** (`requireRole`) dan **ownership validation** (`requireOwnerOrRole`) terpisah — role saja tidak cukup untuk edit resource orang lain.
- **Rate limiting** nyata lewat `express-rate-limit` (10 percobaan/15 menit untuk login & register).
- **Input validation** dengan Zod di setiap endpoint yang menerima body.
- **Audit log** otomatis tertulis ke tabel `audit_logs` untuk setiap aksi sensitif (create/update/delete novel, ubah role user, dst).
- `helmet` untuk HTTP security headers, `cors` dibatasi ke `CLIENT_ORIGIN` tertentu.

## Keterbatasan Jujur
- Ini kode backend sungguhan, tapi **tidak berjalan otomatis** di lingkungan chat ini — perlu dijalankan di komputer/server sendiri dengan Node.js dan PostgreSQL terpasang (atau di-deploy ke layanan seperti Railway/Render/VPS).
- `toggleLike` di komentar saat ini hanya menaikkan counter; untuk mencegah satu user like berkali-kali, tambahkan tabel pivot `comment_likes(user_id, comment_id)` sebelum dipakai di produksi.
- Rate limiter memakai in-memory store (cukup untuk satu instance server); untuk deployment multi-instance, ganti dengan store Redis (`rate-limit-redis`).
