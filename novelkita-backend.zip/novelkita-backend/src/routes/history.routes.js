const router = require('express').Router();
const history = require('../controllers/history.controller');
const { authenticate } = require('../middleware/auth');

router.use(authenticate);
router.post('/', history.upsert);
router.get('/', history.list);

module.exports = router;
