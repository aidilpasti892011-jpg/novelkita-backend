const router = require('express').Router();
const bookmark = require('../controllers/bookmark.controller');
const { authenticate } = require('../middleware/auth');

router.use(authenticate);
router.get('/user', bookmark.listByUser);
router.post('/', bookmark.create);
router.delete('/:id', bookmark.remove);

module.exports = router;
