const router = require('express').Router();
const comment = require('../controllers/comment.controller');
const { authenticate, requireOwnerOrRole } = require('../middleware/auth');

router.get('/novel/:id', comment.listByNovel);
router.post('/', authenticate, comment.create);
router.post('/:id/like', authenticate, comment.toggleLike);
router.put('/:id', authenticate, comment.update);
router.delete('/:id', authenticate, requireOwnerOrRole(comment.getCommentOwnerId, 'ADMIN', 'SUPER_ADMIN'), comment.remove);

module.exports = router;
