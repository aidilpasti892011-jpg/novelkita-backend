const router = require('express').Router();
const novel = require('../controllers/novel.controller');
const { authenticate, optionalAuth, requireRole, requireOwnerOrRole } = require('../middleware/auth');

router.get('/', optionalAuth, novel.list);
router.get('/:id', optionalAuth, novel.getById);
router.post('/', authenticate, requireRole('AUTHOR', 'ADMIN', 'SUPER_ADMIN'), novel.create);
router.put('/:id', authenticate, requireOwnerOrRole(novel.getNovelOwnerId, 'ADMIN', 'SUPER_ADMIN'), novel.update);
router.delete('/:id', authenticate, requireOwnerOrRole(novel.getNovelOwnerId, 'ADMIN', 'SUPER_ADMIN'), novel.remove);

module.exports = router;
