const router = require('express').Router();
const admin = require('../controllers/admin.controller');
const { authenticate, requireRole } = require('../middleware/auth');

// Seluruh route di file ini wajib login DAN berrole ADMIN atau SUPER_ADMIN
router.use(authenticate, requireRole('ADMIN', 'SUPER_ADMIN'));

router.get('/users', admin.listUsers);
router.put('/users/:id', admin.updateUser);
router.delete('/users/:id', admin.deleteUser);

router.get('/novels', admin.listAllNovels);
router.put('/novels/:id/status', admin.setNovelStatus);

router.put('/comments/:id/hide', admin.hideComment);
router.put('/comments/:id/unhide', admin.unhideComment);

router.get('/reports', admin.listReports);
router.put('/reports/:id', admin.updateReport);

// Audit log khusus SUPER_ADMIN
router.get('/audit-logs', requireRole('SUPER_ADMIN'), admin.listAuditLogs);

module.exports = router;
