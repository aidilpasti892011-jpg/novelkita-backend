const router = require('express').Router();
const admin = require('../controllers/admin.controller');
const { authenticate } = require('../middleware/auth');

// Endpoint publik (user login) untuk MEMBUAT laporan.
// Meninjau/mengubah status laporan ada di /api/admin/reports (khusus admin).
router.post('/', authenticate, admin.createReport);

module.exports = router;
