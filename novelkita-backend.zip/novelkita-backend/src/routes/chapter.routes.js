const router = require('express').Router();
const chapter = require('../controllers/chapter.controller');
const { authenticate, optionalAuth, requireRole, requireOwnerOrRole } = require('../middleware/auth');

router.get('/', optionalAuth, chapter.list);
router.get('/:id', optionalAuth, chapter.getById);
router.post('/', authenticate, requireRole('AUTHOR', 'ADMIN', 'SUPER_ADMIN'), requireOwnerOrRole(chapter.getChapterOwnerId, 'ADMIN', 'SUPER_ADMIN'), chapter.create);
router.put('/:id', authenticate, requireOwnerOrRole(chapter.getChapterOwnerId, 'ADMIN', 'SUPER_ADMIN'), chapter.update);
router.delete('/:id', authenticate, requireOwnerOrRole(chapter.getChapterOwnerId, 'ADMIN', 'SUPER_ADMIN'), chapter.remove);

module.exports = router;
