const express = require('express');
require('express-async-errors');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const cookieParser = require('cookie-parser');
const { apiLimiter } = require('./middleware/rateLimit');

const authRoutes = require('./routes/auth.routes');
const novelRoutes = require('./routes/novel.routes');
const chapterRoutes = require('./routes/chapter.routes');
const bookmarkRoutes = require('./routes/bookmark.routes');
const commentRoutes = require('./routes/comment.routes');
const historyRoutes = require('./routes/history.routes');
const reportRoutes = require('./routes/report.routes');
const adminRoutes = require('./routes/admin.routes');

const app = express();

app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:3000', credentials: true }));
app.use(express.json({ limit: '2mb' })); // 2mb agar isi chapter yang panjang tetap muat
app.use(cookieParser());
if (process.env.NODE_ENV === 'development') app.use(morgan('dev'));
app.use('/api', apiLimiter);

app.get('/api/health', (req, res) => res.json({ status: 'ok', service: 'novelkita-backend' }));

app.use('/api/auth', authRoutes);
app.use('/api/novels', novelRoutes);
app.use('/api/chapters', chapterRoutes);
app.use('/api/bookmarks', bookmarkRoutes);
app.use('/api/comments', commentRoutes);
app.use('/api/history', historyRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/admin', adminRoutes);

// 404 untuk route API yang tidak dikenal
app.use('/api', (req, res) => res.status(404).json({ error: 'Endpoint tidak ditemukan' }));

// Error handler terakhir — menangkap error tak terduga dari controller manapun
app.use((err, req, res, next) => {
  console.error(err);
  if (err.code === 'P2002') return res.status(409).json({ error: 'Data sudah ada (unique constraint)' });
  if (err.code === 'P2025') return res.status(404).json({ error: 'Data tidak ditemukan' });
  res.status(err.status || 500).json({ error: err.message || 'Terjadi kesalahan pada server' });
});

module.exports = app;
