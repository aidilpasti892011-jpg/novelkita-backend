const prisma = require('../lib/prisma');

// Menulis satu baris audit log. Dipanggil dari controller setiap kali ada
// aksi admin/author yang perlu dilacak (edit novel, hapus user, dst).
async function logAudit(actorId, action, targetType = null, targetId = null) {
  try {
    await prisma.auditLog.create({
      data: { actorId, action, targetType, targetId },
    });
  } catch (err) {
    // Audit log tidak boleh menggagalkan request utama — cukup catat ke console.
    console.error('Gagal menulis audit log:', err.message);
  }
}

module.exports = { logAudit };
