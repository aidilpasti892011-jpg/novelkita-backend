const { verifyAccessToken } = require('../utils/jwt');
const prisma = require('../lib/prisma');

// Membaca token dari header Authorization: Bearer <token>, memverifikasinya,
// lalu memuat data user dari DB dan menaruhnya di req.user untuk dipakai
// controller berikutnya.
async function authenticate(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Token akses tidak ditemukan' });

    const payload = verifyAccessToken(token);
    const user = await prisma.user.findUnique({ where: { id: payload.sub } });
    if (!user) return res.status(401).json({ error: 'User tidak ditemukan' });

    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Token tidak valid atau kedaluwarsa' });
  }
}

// Middleware opsional: kalau ada token yang valid, isi req.user; kalau tidak
// ada / tidak valid, tetap lanjut sebagai guest (dipakai di endpoint publik
// yang perilakunya sedikit berbeda untuk user yang login, misalnya GET /novels).
async function optionalAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return next();
  try {
    const payload = verifyAccessToken(token);
    const user = await prisma.user.findUnique({ where: { id: payload.sub } });
    if (user) req.user = user;
  } catch (err) {
    // token invalid — biarkan lanjut sebagai guest, jangan lempar error
  }
  next();
}

// Membatasi endpoint hanya untuk role tertentu. Panggil setelah authenticate().
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Belum login' });
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Kamu tidak punya izin untuk mengakses ini' });
    }
    next();
  };
}

// Mengizinkan aksi jika user adalah PEMILIK resource (mis. author novel itu
// sendiri) ATAU role-nya termasuk salah satu yang diberikan (mis. admin).
// getOwnerId adalah fungsi async yang menerima req dan mengembalikan id pemilik.
function requireOwnerOrRole(getOwnerId, ...roles) {
  return async (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Belum login' });
    if (roles.includes(req.user.role)) return next();
    try {
      const ownerId = await getOwnerId(req);
      if (ownerId && ownerId === req.user.id) return next();
      return res.status(403).json({ error: 'Kamu hanya bisa mengubah milikmu sendiri' });
    } catch (err) {
      return res.status(404).json({ error: 'Data tidak ditemukan' });
    }
  };
}

module.exports = { authenticate, optionalAuth, requireRole, requireOwnerOrRole };
