// Middleware generik untuk memvalidasi req.body memakai skema Zod.
// Kalau invalid, langsung balas 400 dengan detail error; kalau valid,
// req.body diganti dengan hasil parse (sudah ter-trim & typed).
function validateBody(schema) {
  return (req, res, next) => {
    const result = schema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({
        error: 'Input tidak valid',
        details: result.error.flatten().fieldErrors,
      });
    }
    req.body = result.data;
    next();
  };
}

module.exports = { validateBody };
