const rateLimit = require('express-rate-limit');

// Rate limiting untuk endpoint sensitif (login/register) — 10 percobaan per
// 15 menit per IP. Di produksi dengan banyak instance server, ganti store
// default (in-memory) dengan store Redis (rate-limit-redis) agar limitnya
// konsisten lintas instance.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Terlalu banyak percobaan. Coba lagi dalam beberapa menit.' },
});

// Rate limit umum untuk seluruh API, lebih longgar.
const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 120,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Terlalu banyak permintaan, tunggu sebentar.' },
});

module.exports = { authLimiter, apiLimiter };
