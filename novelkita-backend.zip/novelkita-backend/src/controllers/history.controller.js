const { z } = require('zod');
const prisma = require('../lib/prisma');

const historySchema = z.object({
  novelId: z.string().uuid(),
  chapterId: z.string().uuid(),
  progress: z.number().min(0).max(100),
});

// POST /api/history — upsert progres baca, dipanggil berkala dari Reader Mode saat scroll
async function upsert(req, res) {
  const parsed = historySchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Input tidak valid', details: parsed.error.flatten().fieldErrors });
  const { novelId, chapterId, progress } = parsed.data;

  const history = await prisma.readingHistory.upsert({
    where: { userId_novelId: { userId: req.user.id, novelId } },
    update: { chapterId, progress },
    create: { userId: req.user.id, novelId, chapterId, progress },
  });
  res.json({ history });
}

// GET /api/history — dipakai untuk seksi "Lanjutkan Membaca"
async function list(req, res) {
  const items = await prisma.readingHistory.findMany({
    where: { userId: req.user.id },
    include: { novel: true, chapter: { select: { id: true, chapterNumber: true, title: true } } },
    orderBy: { updatedAt: 'desc' },
  });
  res.json({ items });
}

module.exports = { upsert, list };
