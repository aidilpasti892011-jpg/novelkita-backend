const { z } = require('zod');
const prisma = require('../lib/prisma');
const { logAudit } = require('../utils/audit');

const chapterSchema = z.object({
  novelId: z.string().uuid(),
  chapterNumber: z.number().int().positive(),
  title: z.string().min(1).max(255),
  content: z.string().min(1),
  published: z.boolean().optional(),
});

function countWords(text) {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

// GET /api/chapters?novelId=... — daftar chapter suatu novel (published saja untuk publik)
async function list(req, res) {
  const { novelId } = req.query;
  if (!novelId) return res.status(400).json({ error: 'Parameter novelId wajib diisi' });

  const includeUnpublished = req.user && ['AUTHOR', 'ADMIN', 'SUPER_ADMIN'].includes(req.user.role);
  const chapters = await prisma.chapter.findMany({
    where: { novelId, ...(includeUnpublished ? {} : { published: true }) },
    orderBy: { chapterNumber: 'desc' },
  });
  res.json({ items: chapters });
}

// GET /api/chapters/:id — dipakai oleh Reader Mode, isi lengkap chapter
async function getById(req, res) {
  const chapter = await prisma.chapter.findUnique({ where: { id: req.params.id }, include: { novel: { select: { id: true, title: true, authorId: true } } } });
  if (!chapter) return res.status(404).json({ error: 'Chapter tidak ditemukan' });
  if (!chapter.published && (!req.user || (req.user.id !== chapter.novel.authorId && !['ADMIN', 'SUPER_ADMIN'].includes(req.user.role)))) {
    return res.status(403).json({ error: 'Chapter ini belum dipublikasikan' });
  }
  res.json({ chapter });
}

// POST /api/chapters — hanya pemilik novel (dicek route) yang boleh menambah chapter
async function create(req, res) {
  const parsed = chapterSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Input tidak valid', details: parsed.error.flatten().fieldErrors });
  const { novelId, chapterNumber, title, content, published } = parsed.data;

  const novel = await prisma.novel.findUnique({ where: { id: novelId } });
  if (!novel) return res.status(404).json({ error: 'Novel tidak ditemukan' });

  const chapter = await prisma.chapter.create({
    data: { novelId, chapterNumber, title, content, wordCount: countWords(content), published: !!published },
  });
  await logAudit(req.user.id, `Menambah chapter ${chapterNumber} pada novel: ${novel.title}`, 'CHAPTER', chapter.id);
  res.status(201).json({ chapter });
}

// PUT /api/chapters/:id — pemilik novel atau admin
async function update(req, res) {
  const parsed = chapterSchema.partial().safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Input tidak valid', details: parsed.error.flatten().fieldErrors });

  const data = { ...parsed.data };
  if (data.content) data.wordCount = countWords(data.content);

  const chapter = await prisma.chapter.update({ where: { id: req.params.id }, data });
  await logAudit(req.user.id, `Mengedit chapter ${chapter.chapterNumber}`, 'CHAPTER', chapter.id);
  res.json({ chapter });
}

// DELETE /api/chapters/:id
async function remove(req, res) {
  const chapter = await prisma.chapter.findUnique({ where: { id: req.params.id } });
  if (!chapter) return res.status(404).json({ error: 'Chapter tidak ditemukan' });

  await prisma.chapter.delete({ where: { id: req.params.id } });
  await logAudit(req.user.id, `Menghapus chapter ${chapter.chapterNumber}`, 'CHAPTER', chapter.id);
  res.json({ message: 'Chapter dihapus' });
}

// Dipakai oleh requireOwnerOrRole — pemilik chapter = pemilik novel induknya
async function getChapterOwnerId(req) {
  const id = req.params.id || req.body.novelId ? undefined : undefined;
  const chapter = req.params.id
    ? await prisma.chapter.findUnique({ where: { id: req.params.id }, include: { novel: { select: { authorId: true } } } })
    : null;
  if (chapter) return chapter.novel.authorId;
  // Untuk POST /chapters (belum ada chapter id), cek kepemilikan lewat novelId di body
  if (req.body?.novelId) {
    const novel = await prisma.novel.findUnique({ where: { id: req.body.novelId }, select: { authorId: true } });
    return novel?.authorId;
  }
  return null;
}

module.exports = { list, getById, create, update, remove, getChapterOwnerId };
