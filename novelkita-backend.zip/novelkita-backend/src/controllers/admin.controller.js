const { z } = require('zod');
const prisma = require('../lib/prisma');
const { logAudit } = require('../utils/audit');

// ---- Kelola User ----
async function listUsers(req, res) {
  const { role, search } = req.query;
  const users = await prisma.user.findMany({
    where: { ...(role ? { role } : {}), ...(search ? { OR: [{ username: { contains: search, mode: 'insensitive' } }, { email: { contains: search, mode: 'insensitive' } }] } : {}) },
    select: { id: true, username: true, email: true, role: true, avatar: true, createdAt: true },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ items: users });
}

const updateUserSchema = z.object({ role: z.enum(['READER', 'AUTHOR', 'ADMIN', 'SUPER_ADMIN']).optional() });

async function updateUser(req, res) {
  const parsed = updateUserSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Input tidak valid' });
  // Hanya SUPER_ADMIN yang boleh menaikkan seseorang jadi ADMIN/SUPER_ADMIN
  if (parsed.data.role && ['ADMIN', 'SUPER_ADMIN'].includes(parsed.data.role) && req.user.role !== 'SUPER_ADMIN') {
    return res.status(403).json({ error: 'Hanya Super Admin yang boleh memberi role Admin/Super Admin' });
  }
  const user = await prisma.user.update({ where: { id: req.params.id }, data: parsed.data });
  await logAudit(req.user.id, `Mengubah role user ${user.username} menjadi ${user.role}`, 'USER', user.id);
  res.json({ user });
}

async function deleteUser(req, res) {
  const user = await prisma.user.delete({ where: { id: req.params.id } });
  await logAudit(req.user.id, `Menghapus user: ${user.username}`, 'USER', user.id);
  res.json({ message: 'User dihapus' });
}

// ---- Kelola Novel (override admin, bebas dari batasan "pemilik saja") ----
async function listAllNovels(req, res) {
  const novels = await prisma.novel.findMany({
    include: { author: { select: { username: true } } },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ items: novels });
}

async function setNovelStatus(req, res) {
  const status = z.enum(['DRAFT', 'PUBLISHED', 'HIDDEN']).safeParse(req.body.status);
  if (!status.success) return res.status(400).json({ error: 'Status tidak valid' });
  const novel = await prisma.novel.update({ where: { id: req.params.id }, data: { status: status.data } });
  await logAudit(req.user.id, `Mengubah status novel ${novel.title} menjadi ${status.data}`, 'NOVEL', novel.id);
  res.json({ novel });
}

// ---- Kelola Komentar ----
async function hideComment(req, res) {
  const comment = await prisma.comment.update({ where: { id: req.params.id }, data: { hidden: true } });
  await logAudit(req.user.id, 'Menyembunyikan komentar', 'COMMENT', comment.id);
  res.json({ comment });
}
async function unhideComment(req, res) {
  const comment = await prisma.comment.update({ where: { id: req.params.id }, data: { hidden: false } });
  await logAudit(req.user.id, 'Menampilkan kembali komentar', 'COMMENT', comment.id);
  res.json({ comment });
}

// ---- Kelola Laporan ----
async function listReports(req, res) {
  const { status } = req.query;
  const reports = await prisma.report.findMany({
    where: status ? { status } : {},
    include: { reporter: { select: { username: true } } },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ items: reports });
}

async function updateReport(req, res) {
  const status = z.enum(['PENDING', 'REVIEWED', 'REJECTED', 'ACTIONED']).safeParse(req.body.status);
  if (!status.success) return res.status(400).json({ error: 'Status tidak valid' });
  const report = await prisma.report.update({ where: { id: req.params.id }, data: { status: status.data } });
  await logAudit(req.user.id, `Laporan diubah ke status ${status.data}`, 'REPORT', report.id);
  res.json({ report });
}

const createReportSchema = z.object({
  targetType: z.enum(['NOVEL', 'COMMENT', 'USER']),
  targetId: z.string().uuid(),
  reason: z.string().min(1).max(1000),
});
async function createReport(req, res) {
  const parsed = createReportSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Input tidak valid' });
  const report = await prisma.report.create({ data: { ...parsed.data, reporterId: req.user.id } });
  res.status(201).json({ report });
}

// ---- Audit Log ----
async function listAuditLogs(req, res) {
  const logs = await prisma.auditLog.findMany({
    include: { actor: { select: { username: true } } },
    orderBy: { createdAt: 'desc' },
    take: 200,
  });
  res.json({ items: logs });
}

module.exports = {
  listUsers, updateUser, deleteUser,
  listAllNovels, setNovelStatus,
  hideComment, unhideComment,
  listReports, updateReport, createReport,
  listAuditLogs,
};
