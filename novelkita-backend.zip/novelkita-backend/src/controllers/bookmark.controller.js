const { z } = require('zod');
const prisma = require('../lib/prisma');

const bookmarkSchema = z.object({ novelId: z.string().uuid() });

// POST /api/bookmarks
async function create(req, res) {
  const parsed = bookmarkSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'novelId wajib diisi' });

  const existing = await prisma.bookmark.findUnique({
    where: { userId_novelId: { userId: req.user.id, novelId: parsed.data.novelId } },
  });
  if (existing) return res.status(409).json({ error: 'Novel ini sudah di-bookmark' });

  const bookmark = await prisma.bookmark.create({ data: { userId: req.user.id, novelId: parsed.data.novelId } });
  await prisma.novel.update({ where: { id: parsed.data.novelId }, data: { totalBookmarks: { increment: 1 } } });
  res.status(201).json({ bookmark });
}

// DELETE /api/bookmarks/:id — :id di sini adalah novelId, sesuai kontrak "Library User"
async function remove(req, res) {
  const novelId = req.params.id;
  const deleted = await prisma.bookmark.deleteMany({ where: { userId: req.user.id, novelId } });
  if (deleted.count > 0) {
    await prisma.novel.update({ where: { id: novelId }, data: { totalBookmarks: { decrement: 1 } } }).catch(() => {});
  }
  res.json({ message: 'Bookmark dihapus' });
}

// GET /api/bookmarks/user — dipakai halaman Library
async function listByUser(req, res) {
  const bookmarks = await prisma.bookmark.findMany({
    where: { userId: req.user.id },
    include: { novel: { include: { author: { select: { username: true } } } } },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ items: bookmarks });
}

module.exports = { create, remove, listByUser };
