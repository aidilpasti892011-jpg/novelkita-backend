const { z } = require('zod');
const prisma = require('../lib/prisma');
const { logAudit } = require('../utils/audit');

const novelSchema = z.object({
  title: z.string().min(1).max(255),
  alternativeTitle: z.string().max(255).optional(),
  synopsis: z.string().min(1),
  coverUrl: z.string().url().optional().nullable(),
  bannerUrl: z.string().url().optional().nullable(),
  genre: z.string().min(1),
  tags: z.array(z.string()).optional(),
  status: z.enum(['DRAFT', 'PUBLISHED', 'HIDDEN']).optional(),
});

// GET /api/novels — daftar novel publik, dengan filter genre/status/search + pagination
async function list(req, res) {
  const { genre, status, search, authorId, page = '1', limit = '20' } = req.query;
  const take = Math.min(parseInt(limit) || 20, 50);
  const skip = (Math.max(parseInt(page) || 1, 1) - 1) * take;

  const where = {
    ...(genre ? { genre } : {}),
    ...(authorId ? { authorId } : {}),
    ...(search ? { title: { contains: search, mode: 'insensitive' } } : {}),
    // Publik hanya melihat novel published, kecuali dia author/admin yang memanggil lewat /dashboard
    status: status || 'PUBLISHED',
  };

  const [items, total] = await Promise.all([
    prisma.novel.findMany({
      where,
      include: { author: { select: { id: true, username: true, avatar: true } } },
      orderBy: { createdAt: 'desc' },
      take,
      skip,
    }),
    prisma.novel.count({ where }),
  ]);

  res.json({ items, total, page: Number(page), limit: take });
}

// GET /api/novels/:id — detail novel + daftar chapter (published saja untuk publik)
async function getById(req, res) {
  const novel = await prisma.novel.findUnique({
    where: { id: req.params.id },
    include: {
      author: { select: { id: true, username: true, avatar: true, bio: true } },
      chapters: { where: { published: true }, orderBy: { chapterNumber: 'desc' }, select: { id: true, chapterNumber: true, title: true, wordCount: true, createdAt: true } },
    },
  });
  if (!novel) return res.status(404).json({ error: 'Novel tidak ditemukan' });

  // increment total_views secara async, tidak perlu ditunggu request selesai
  prisma.novel.update({ where: { id: novel.id }, data: { totalViews: { increment: 1 } } }).catch(() => {});

  res.json({ novel });
}

// POST /api/novels — hanya AUTHOR/ADMIN/SUPER_ADMIN, authorId diambil dari token (bukan dari body)
async function create(req, res) {
  const parsed = novelSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Input tidak valid', details: parsed.error.flatten().fieldErrors });

  const novel = await prisma.novel.create({
    data: { ...parsed.data, authorId: req.user.id, status: parsed.data.status || 'DRAFT' },
  });
  await logAudit(req.user.id, 'Membuat novel: ' + novel.title, 'NOVEL', novel.id);
  res.status(201).json({ novel });
}

// PUT /api/novels/:id — pemilik novel atau admin (dicek oleh middleware requireOwnerOrRole di route)
async function update(req, res) {
  const parsed = novelSchema.partial().safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Input tidak valid', details: parsed.error.flatten().fieldErrors });

  const novel = await prisma.novel.update({ where: { id: req.params.id }, data: parsed.data });
  await logAudit(req.user.id, 'Mengedit novel: ' + novel.title, 'NOVEL', novel.id);
  res.json({ novel });
}

// DELETE /api/novels/:id — pemilik novel atau admin
async function remove(req, res) {
  const novel = await prisma.novel.findUnique({ where: { id: req.params.id } });
  if (!novel) return res.status(404).json({ error: 'Novel tidak ditemukan' });

  await prisma.novel.delete({ where: { id: req.params.id } });
  await logAudit(req.user.id, 'Menghapus novel: ' + novel.title, 'NOVEL', novel.id);
  res.json({ message: 'Novel dihapus' });
}

// Dipakai oleh middleware requireOwnerOrRole untuk PUT/DELETE novel
async function getNovelOwnerId(req) {
  const novel = await prisma.novel.findUnique({ where: { id: req.params.id }, select: { authorId: true } });
  return novel?.authorId;
}

module.exports = { list, getById, create, update, remove, getNovelOwnerId };
