const { z } = require('zod');
const prisma = require('../lib/prisma');

const commentSchema = z.object({
  novelId: z.string().uuid(),
  chapterId: z.string().uuid().optional().nullable(),
  parentCommentId: z.string().uuid().optional().nullable(),
  content: z.string().min(1).max(2000),
});

// POST /api/comments — dipakai untuk komentar baru maupun balasan (lewat parentCommentId)
async function create(req, res) {
  const parsed = commentSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Input tidak valid', details: parsed.error.flatten().fieldErrors });

  const comment = await prisma.comment.create({
    data: { ...parsed.data, userId: req.user.id },
    include: { user: { select: { id: true, username: true, avatar: true } } },
  });
  await prisma.novel.update({ where: { id: parsed.data.novelId }, data: { totalComments: { increment: 1 } } }).catch(() => {});
  res.status(201).json({ comment });
}

// PUT /api/comments/:id — edit isi komentar (pemilik saja) ATAU like (lihat toggleLike di bawah)
async function update(req, res) {
  const comment = await prisma.comment.findUnique({ where: { id: req.params.id } });
  if (!comment) return res.status(404).json({ error: 'Komentar tidak ditemukan' });
  if (comment.userId !== req.user.id) return res.status(403).json({ error: 'Kamu hanya bisa mengedit komentarmu sendiri' });

  const content = z.string().min(1).max(2000).safeParse(req.body.content);
  if (!content.success) return res.status(400).json({ error: 'Isi komentar tidak valid' });

  const updated = await prisma.comment.update({ where: { id: req.params.id }, data: { content: content.data } });
  res.json({ comment: updated });
}

// POST /api/comments/:id/like — toggle like sederhana (naikkan counter)
// Catatan: untuk mencegah 1 user like berkali-kali, tabel comment_likes(user_id, comment_id)
// terpisah lebih tepat di produksi — di sini counter langsung demi kesederhanaan awal.
async function toggleLike(req, res) {
  const comment = await prisma.comment.update({
    where: { id: req.params.id },
    data: { likes: { increment: 1 } },
  });
  res.json({ comment });
}

// DELETE /api/comments/:id — pemilik komentar atau admin (dicek route)
async function remove(req, res) {
  const comment = await prisma.comment.findUnique({ where: { id: req.params.id } });
  if (!comment) return res.status(404).json({ error: 'Komentar tidak ditemukan' });

  await prisma.comment.delete({ where: { id: req.params.id } });
  await prisma.novel.update({ where: { id: comment.novelId }, data: { totalComments: { decrement: 1 } } }).catch(() => {});
  res.json({ message: 'Komentar dihapus' });
}

// GET /api/comments/novel/:id — thread komentar lengkap (top-level + replies bersarang)
async function listByNovel(req, res) {
  const comments = await prisma.comment.findMany({
    where: { novelId: req.params.id, parentCommentId: null, hidden: false },
    include: {
      user: { select: { id: true, username: true, avatar: true } },
      replies: { include: { user: { select: { id: true, username: true, avatar: true } } }, orderBy: { createdAt: 'asc' } },
    },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ items: comments });
}

async function getCommentOwnerId(req) {
  const comment = await prisma.comment.findUnique({ where: { id: req.params.id }, select: { userId: true } });
  return comment?.userId;
}

module.exports = { create, update, toggleLike, remove, listByNovel, getCommentOwnerId };
