const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { z } = require('zod');
const prisma = require('../lib/prisma');
const { signAccessToken, signRefreshToken, verifyRefreshToken, refreshExpiryDate } = require('../utils/jwt');
const { logAudit } = require('../utils/audit');

const registerSchema = z.object({
  username: z.string().min(3).max(32),
  email: z.string().email(),
  password: z.string().min(8),
});
const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

function publicUser(user) {
  const { passwordHash, ...rest } = user;
  return rest;
}

function setRefreshCookie(res, token) {
  res.cookie('refreshToken', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: '/api/auth',
  });
}

// POST /api/auth/register
async function register(req, res) {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Input tidak valid', details: parsed.error.flatten().fieldErrors });
  const { username, email, password } = parsed.data;

  const existing = await prisma.user.findFirst({ where: { OR: [{ email }, { username }] } });
  if (existing) {
    return res.status(409).json({ error: existing.email === email ? 'Email sudah terdaftar' : 'Username sudah digunakan' });
  }

  const passwordHash = await bcrypt.hash(password, 12);
  const user = await prisma.user.create({
    data: { username, email, passwordHash, role: 'READER' },
  });

  const accessToken = signAccessToken(user);
  const refreshToken = signRefreshToken(user);
  await prisma.refreshToken.create({
    data: { userId: user.id, tokenHash: hashToken(refreshToken), expiresAt: refreshExpiryDate() },
  });
  setRefreshCookie(res, refreshToken);
  await logAudit(user.id, 'Register akun baru', 'USER', user.id);

  res.status(201).json({ user: publicUser(user), accessToken });
}

// POST /api/auth/login
async function login(req, res) {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Input tidak valid' });
  const { email, password } = parsed.data;

  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) return res.status(401).json({ error: 'Email atau password salah' });

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) return res.status(401).json({ error: 'Email atau password salah' });

  const accessToken = signAccessToken(user);
  const refreshToken = signRefreshToken(user);
  await prisma.refreshToken.create({
    data: { userId: user.id, tokenHash: hashToken(refreshToken), expiresAt: refreshExpiryDate() },
  });
  setRefreshCookie(res, refreshToken);
  await logAudit(user.id, 'Login', 'USER', user.id);

  res.json({ user: publicUser(user), accessToken });
}

// POST /api/auth/logout
async function logout(req, res) {
  const token = req.cookies?.refreshToken;
  if (token) {
    try {
      const payload = verifyRefreshToken(token);
      await prisma.refreshToken.deleteMany({ where: { userId: payload.sub, tokenHash: hashToken(token) } });
      await logAudit(payload.sub, 'Logout', 'USER', payload.sub);
    } catch (err) {
      // token sudah invalid/expired — tidak masalah, tetap lanjut clear cookie
    }
  }
  res.clearCookie('refreshToken', { path: '/api/auth' });
  res.json({ message: 'Berhasil logout' });
}

// POST /api/auth/refresh — menukar refresh token (cookie httpOnly) dengan access token baru
async function refresh(req, res) {
  const token = req.cookies?.refreshToken;
  if (!token) return res.status(401).json({ error: 'Refresh token tidak ditemukan' });
  try {
    const payload = verifyRefreshToken(token);
    const stored = await prisma.refreshToken.findFirst({
      where: { userId: payload.sub, tokenHash: hashToken(token), expiresAt: { gt: new Date() } },
    });
    if (!stored) return res.status(401).json({ error: 'Refresh token tidak valid, silakan login ulang' });

    const user = await prisma.user.findUnique({ where: { id: payload.sub } });
    if (!user) return res.status(401).json({ error: 'User tidak ditemukan' });

    const accessToken = signAccessToken(user);
    res.json({ accessToken });
  } catch (err) {
    return res.status(401).json({ error: 'Refresh token tidak valid atau kedaluwarsa' });
  }
}

// GET /api/auth/me
async function me(req, res) {
  res.json({ user: publicUser(req.user) });
}

module.exports = { register, login, logout, refresh, me };
