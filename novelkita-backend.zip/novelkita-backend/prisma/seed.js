// Seed data awal — setara dengan data dummy yang dipakai di prototipe frontend
// (Tahta yang Retak, dkk), supaya begitu backend ini disambungkan, tampilannya
// tidak kosong. Jalankan dengan: npm run seed

const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');
const prisma = new PrismaClient();

async function main() {
  const passwordHash = await bcrypt.hash('password123', 12);

  const author = await prisma.user.upsert({
    where: { email: 'wirasena@novelkita.id' },
    update: {},
    create: {
      username: 'A. Wirasena',
      email: 'wirasena@novelkita.id',
      passwordHash,
      role: 'AUTHOR',
      bio: 'Penulis fantasi kerajaan. Suka dunia politik istana, reinkarnasi, dan cerita slow-burn.',
    },
  });

  const admin = await prisma.user.upsert({
    where: { email: 'admin@novelkita.id' },
    update: {},
    create: { username: 'Admin Utama', email: 'admin@novelkita.id', passwordHash, role: 'ADMIN' },
  });

  const superAdmin = await prisma.user.upsert({
    where: { email: 'superadmin@novelkita.id' },
    update: {},
    create: { username: 'Super Admin', email: 'superadmin@novelkita.id', passwordHash, role: 'SUPER_ADMIN' },
  });

  const reader = await prisma.user.upsert({
    where: { email: 'rina@novelkita.id' },
    update: {},
    create: { username: 'Rina Anggraini', email: 'rina@novelkita.id', passwordHash, role: 'READER' },
  });

  const novel = await prisma.novel.upsert({
    where: { id: '00000000-0000-0000-0000-000000000001' },
    update: {},
    create: {
      id: '00000000-0000-0000-0000-000000000001',
      title: 'Tahta yang Retak',
      alternativeTitle: 'The Cracked Throne',
      synopsis: 'Seorang pewaris takhta yang dibuang harus merebut kembali kerajaannya dari bayang konspirasi istana.',
      authorId: author.id,
      status: 'PUBLISHED',
      genre: 'Fantasi',
      tags: ['Reinkarnasi', 'Politik Istana'],
      rating: 4.8,
    },
  });

  await prisma.chapter.upsert({
    where: { novelId_chapterNumber: { novelId: novel.id, chapterNumber: 1 } },
    update: {},
    create: {
      novelId: novel.id,
      chapterNumber: 1,
      title: 'Awal Keruntuhan',
      content: 'Angin malam menyusup lewat celah jendela, membawa aroma hujan yang baru saja reda...',
      wordCount: 42,
      published: true,
    },
  });

  console.log('Seed selesai. Akun demo (password semua: password123):');
  console.log('- Author:      wirasena@novelkita.id');
  console.log('- Admin:       admin@novelkita.id');
  console.log('- Super Admin: superadmin@novelkita.id');
  console.log('- Reader:      rina@novelkita.id');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
